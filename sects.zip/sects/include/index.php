<?php
header('Location: /');
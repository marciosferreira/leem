<?php
require_once __DIR__ . '/sects/index.php';
